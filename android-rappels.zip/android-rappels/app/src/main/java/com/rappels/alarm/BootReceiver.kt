package com.rappels.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.rappels.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != "android.intent.action.QUICKBOOT_POWERON") return

        CoroutineScope(Dispatchers.IO).launch {
            AppDatabase.get(context).taskDao().getPending().forEach { task ->
                AlarmScheduler.schedule(context, task)
            }
        }
    }
}
