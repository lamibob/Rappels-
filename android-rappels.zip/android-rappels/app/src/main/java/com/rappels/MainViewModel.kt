package com.rappels

import android.app.AlarmManager
import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.rappels.alarm.AlarmScheduler
import com.rappels.data.AppDatabase
import com.rappels.data.Task
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).taskDao()

    val tasks = dao.getAll().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList()
    )

    fun addTask(
        title: String,
        message: String,
        triggerAt: Long,
        recurrence: String,
        recurrenceEvery: Int,
        reminderType: String,
        colorIndex: Int
    ) = viewModelScope.launch {
        val task = Task(
            title = title,
            message = message,
            triggerAt = triggerAt,
            recurrence = recurrence,
            recurrenceEvery = recurrenceEvery,
            reminderType = reminderType,
            colorIndex = colorIndex
        )
        val id = dao.upsert(task).toInt()
        AlarmScheduler.schedule(getApplication(), task.copy(id = id))
    }

    fun toggleDone(task: Task) = viewModelScope.launch {
        val updated = task.copy(done = !task.done)
        dao.update(updated)
        if (updated.done) AlarmScheduler.cancel(getApplication(), task.id)
        else AlarmScheduler.schedule(getApplication(), updated)
    }

    fun deleteTask(task: Task) = viewModelScope.launch {
        AlarmScheduler.cancel(getApplication(), task.id)
        dao.delete(task)
    }

    fun canScheduleExactAlarms(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getApplication<Application>().getSystemService(Context.ALARM_SERVICE) as AlarmManager
            return am.canScheduleExactAlarms()
        }
        return true
    }

    fun openExactAlarmSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.startActivity(
                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:${context.packageName}"))
            )
        }
    }
}
