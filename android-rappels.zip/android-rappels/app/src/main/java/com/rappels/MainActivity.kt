package com.rappels

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rappels.data.Task
import java.text.SimpleDateFormat
import java.util.*

// ─── Design tokens ──────────────────────────────────────────────────────────
private val BG     = Color(0xFF08080F)
private val CARD   = Color(0xFF12121E)
private val MONO   = FontFamily.Monospace

val PALETTE = listOf(
    Color(0xFFFF6B6B), Color(0xFFFFA94D), Color(0xFFFFD43B), Color(0xFF69DB7C),
    Color(0xFF4DABF7), Color(0xFFCC5DE8), Color(0xFFF783AC), Color(0xFF38D9A9)
)

// ─── Activity ────────────────────────────────────────────────────────────────
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = BG, surface = CARD)) {
                RappelsApp()
            }
        }
    }
}

// ─── Root composable ─────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RappelsApp(vm: MainViewModel = viewModel()) {
    val tasks by vm.tasks.collectAsState()
    val context = LocalContext.current
    var showAdd by remember { mutableStateOf(false) }
    var canAlarm by remember { mutableStateOf(vm.canScheduleExactAlarms()) }

    // Request POST_NOTIFICATIONS on Android 13+
    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    Scaffold(
        containerColor = BG,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAdd = true },
                containerColor = Color(0xFFFF6B6B),
                contentColor = Color.Black
            ) { Icon(Icons.Default.Add, "Ajouter") }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {

            // ── Header ────────────────────────────────────────────────────────
            Column(Modifier.padding(18.dp, 20.dp, 18.dp, 12.dp)) {
                Text("⏰ RAPPELS", fontFamily = MONO, fontSize = 22.sp,
                    fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(4.dp))
                Box(Modifier.fillMaxWidth().height(2.dp).background(
                    Brush.horizontalGradient(listOf(Color(0xFFFF6B6B), Color(0xFF4DABF7), Color.Transparent))
                ))
            }

            // ── Alarm permission banner ───────────────────────────────────────
            if (!canAlarm) {
                Row(Modifier.fillMaxWidth().padding(14.dp, 0.dp, 14.dp, 10.dp)
                    .background(Color(0xFF141100), RoundedCornerShape(8.dp)).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("⚠️ Autorisez les alarmes exactes pour des rappels précis",
                        color = Color(0xFFAA9900), fontSize = 11.sp, fontFamily = MONO,
                        modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { vm.openExactAlarmSettings(context); canAlarm = vm.canScheduleExactAlarms() }) {
                        Text("Autoriser", fontSize = 11.sp, fontFamily = MONO)
                    }
                }
            }

            // ── Task lists ────────────────────────────────────────────────────
            val pending = tasks.filter { !it.done }.sortedBy { it.triggerAt }
            val done    = tasks.filter {  it.done }.sortedByDescending { it.createdAt }

            if (tasks.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Aucune tâche\nTouchez ＋ pour commencer",
                        color = Color(0xFF252535), fontFamily = MONO, fontSize = 13.sp,
                        textAlign = TextAlign.Center, lineHeight = 22.sp)
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(14.dp, 0.dp, 14.dp, 100.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (pending.isNotEmpty()) {
                        item { SectionLabel("À FAIRE — ${pending.size}") }
                        items(pending, key = { it.id }) { t ->
                            TaskCard(t, { vm.toggleDone(t) }, { vm.deleteTask(t) })
                        }
                    }
                    if (done.isNotEmpty()) {
                        item { Spacer(Modifier.height(6.dp)); SectionLabel("TERMINÉ — ${done.size}") }
                        items(done, key = { it.id }) { t ->
                            TaskCard(t, { vm.toggleDone(t) }, { vm.deleteTask(t) })
                        }
                    }
                }
            }
        }

        if (showAdd) {
            AddTaskSheet(
                onDismiss = { showAdd = false },
                onSave = { title, msg, triggerAt, rec, every, type, colorIdx ->
                    vm.addTask(title, msg, triggerAt, rec, every, type, colorIdx)
                    showAdd = false
                }
            )
        }
    }
}

// ─── Section label ───────────────────────────────────────────────────────────
@Composable
fun SectionLabel(text: String) {
    Text(text, fontFamily = MONO, fontSize = 10.sp,
        color = Color(0xFF2A2A3A), letterSpacing = 3.sp,
        modifier = Modifier.padding(vertical = 4.dp))
}

// ─── Task card ───────────────────────────────────────────────────────────────
@Composable
fun TaskCard(task: Task, onToggle: () -> Unit, onDelete: () -> Unit) {
    val color  = PALETTE.getOrElse(task.colorIndex) { PALETTE[0] }
    val isDone = task.done

    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = if (isDone) Color(0xFF0E0E18) else CARD),
        shape = RoundedCornerShape(11.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
            // Accent bar
            Box(Modifier.width(3.dp).fillMaxHeight()
                .background(if (isDone) Color(0xFF222232) else color))

            Row(Modifier.weight(1f).padding(10.dp),
                verticalAlignment = Alignment.CenterVertically) {

                // Checkbox
                Box(
                    Modifier.size(24.dp)
                        .border(2.dp, if (isDone) Color(0xFF2A2A3A) else color, RoundedCornerShape(6.dp))
                        .background(if (isDone) Color(0xFF1A1A28) else Color.Transparent, RoundedCornerShape(6.dp))
                        .clickable { onToggle() },
                    contentAlignment = Alignment.Center
                ) {
                    if (isDone) Text("✓", color = Color(0xFF69DB7C), fontSize = 13.sp, fontFamily = MONO)
                }

                Spacer(Modifier.width(10.dp))

                // Text & pills
                Column(Modifier.weight(1f)) {
                    Text(
                        task.title,
                        fontFamily = MONO,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White.copy(alpha = if (isDone) 0.35f else 1f),
                        textDecoration = if (isDone) TextDecoration.LineThrough else null
                    )
                    Spacer(Modifier.height(5.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (!isDone) {
                            Pill(formatTrigger(task.triggerAt), color)
                            recurrenceLabel(task)?.let { Pill(it, Color(0xFF555566)) }
                        } else {
                            Pill(SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE).format(Date(task.triggerAt)), Color(0xFF2A2A3A))
                        }
                        Pill(reminderIcon(task.reminderType) + " " + reminderName(task.reminderType), Color(0xFF333344))
                    }
                }

                // Delete
                IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.Delete, "Supprimer",
                        tint = Color(0xFF2A2A3A), modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun Pill(text: String, color: Color) {
    Box(Modifier.background(Color(0xFF181828), RoundedCornerShape(20.dp))
        .padding(horizontal = 7.dp, vertical = 2.dp)) {
        Text(text, fontSize = 10.sp, color = color, fontFamily = MONO, fontWeight = FontWeight.Bold)
    }
}

// ─── Formatters ──────────────────────────────────────────────────────────────
fun formatTrigger(ms: Long): String {
    if (ms <= 0) return "—"
    val diff = ms - System.currentTimeMillis()
    return when {
        diff < 0              -> "Passé"
        diff < 60_000         -> "< 1 min"
        diff < 3_600_000      -> "dans ${diff / 60_000} min"
        diff < 86_400_000     -> "dans ${diff / 3_600_000} h"
        diff < 7*86_400_000L  -> "dans ${diff / 86_400_000} j"
        else -> SimpleDateFormat("dd MMM HH:mm", Locale.FRANCE).format(Date(ms))
    }
}

fun recurrenceLabel(task: Task): String? {
    if (task.recurrence == "none") return null
    val map = mapOf("minutes" to "min","hours" to "h","days" to "j","weeks" to "sem","months" to "mois","years" to "an(s)")
    return "↻ /${task.recurrenceEvery}${map[task.recurrence] ?: ""}"
}

fun reminderIcon(t: String) = when(t) { "alarm" -> "🔔"; "notif" -> "📩"; "vibrate" -> "📳"; "all" -> "⚡"; else -> "🔊" }
fun reminderName(t: String) = when(t) { "alarm" -> "Alarme"; "notif" -> "Notif"; "vibrate" -> "Vibreur"; "all" -> "Tout"; else -> "Bip" }

// ─── Add task bottom sheet ───────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTaskSheet(
    onDismiss: () -> Unit,
    onSave: (String, String, Long, String, Int, String, Int) -> Unit
) {
    val context = LocalContext.current
    var title          by remember { mutableStateOf("") }
    var message        by remember { mutableStateOf("") }
    var calendar       by remember { mutableStateOf(Calendar.getInstance().apply { add(Calendar.MINUTE, 10) }) }
    var recurrence     by remember { mutableStateOf("none") }
    var recurrenceN    by remember { mutableStateOf("1") }
    var reminderType   by remember { mutableStateOf("beep") }
    var colorIdx       by remember { mutableStateOf(0) }
    var titleError     by remember { mutableStateOf(false) }

    val dateFmt = remember { SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE) }
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.FRANCE) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF10101A),
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
    ) {
        Column(
            Modifier.fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(18.dp, 0.dp, 18.dp, 36.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Nouvelle tâche", fontFamily = MONO, fontWeight = FontWeight.Bold,
                fontSize = 17.sp, color = Color.White)
            Spacer(Modifier.height(2.dp))

            // Title
            OutlinedTextField(
                value = title, onValueChange = { title = it; titleError = false },
                label = { Text("Nom de la tâche *", fontFamily = MONO) },
                isError = titleError,
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = fieldColors()
            )

            // Date + Time
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        DatePickerDialog(context, { _, y, m, d ->
                            calendar = (calendar.clone() as Calendar).apply { set(y, m, d) }
                        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                            calendar.get(Calendar.DAY_OF_MONTH)).show()
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCCCCDD))
                ) { Text("📅 ${dateFmt.format(calendar.time)}", fontFamily = MONO, fontSize = 12.sp) }

                OutlinedButton(
                    onClick = {
                        TimePickerDialog(context, { _, h, min ->
                            calendar = (calendar.clone() as Calendar).apply {
                                set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, min); set(Calendar.SECOND, 0)
                            }
                        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show()
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFCCCCDD))
                ) { Text("⏰ ${timeFmt.format(calendar.time)}", fontFamily = MONO, fontSize = 12.sp) }
            }

            // Recurrence
            SmallLabel("RÉPÉTITION")
            val recOptions = listOf(
                "none" to "Aucune","minutes" to "Minutes","hours" to "Heures","days" to "Jours",
                "weeks" to "Semaines","months" to "Mois","years" to "Ans"
            )
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                recOptions.chunked(4).forEach { chunk ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        chunk.forEach { (v, l) ->
                            SelectChip(v == recurrence, l, Modifier.weight(1f)) { recurrence = v }
                        }
                        repeat(4 - chunk.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            if (recurrence != "none") {
                OutlinedTextField(
                    value = recurrenceN,
                    onValueChange = { recurrenceN = it.filter { c -> c.isDigit() }.take(4).ifEmpty { "1" } },
                    label = { Text("Répéter tous les N …", fontFamily = MONO) },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp), colors = fieldColors()
                )
            }

            // Reminder type
            SmallLabel("TYPE DE RAPPEL")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("beep" to "🔊 Bip","alarm" to "🔔 Alarme","notif" to "📩 Notif",
                    "vibrate" to "📳 Vibreur","all" to "⚡ Tout").forEach { (v, l) ->
                    SelectChip(v == reminderType, l, Modifier.weight(1f)) { reminderType = v }
                }
            }

            // Message
            OutlinedTextField(
                value = message, onValueChange = { message = it },
                label = { Text("Message personnalisé (optionnel)", fontFamily = MONO) },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp), colors = fieldColors()
            )

            // Color
            SmallLabel("COULEUR")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PALETTE.forEachIndexed { i, c ->
                    Box(
                        Modifier.size(30.dp).clip(CircleShape).background(c)
                            .clickable { colorIdx = i }
                            .then(if (colorIdx == i) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
                    )
                }
            }

            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    if (title.isBlank()) { titleError = true; return@Button }
                    onSave(title.trim(), message.trim(), calendar.timeInMillis,
                        recurrence, recurrenceN.toIntOrNull() ?: 1, reminderType, colorIdx)
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF6B6B)),
                shape = RoundedCornerShape(9.dp)
            ) {
                Text("ENREGISTRER LE RAPPEL", fontFamily = MONO,
                    fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
            }
        }
    }
}

@Composable
fun SmallLabel(text: String) {
    Text(text, fontFamily = MONO, fontSize = 10.sp, color = Color(0xFF444455), letterSpacing = 2.sp)
}

@Composable
fun SelectChip(selected: Boolean, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(7.dp))
            .background(if (selected) Color(0xFF0E1420) else Color(0xFF0D0D18))
            .border(1.dp, if (selected) Color(0xFF4DABF7) else Color(0xFF1E1E2C), RoundedCornerShape(7.dp))
            .clickable { onClick() }
            .padding(horizontal = 4.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontFamily = MONO, fontSize = 10.sp,
            color = if (selected) Color(0xFF4DABF7) else Color(0xFF555566),
            textAlign = TextAlign.Center)
    }
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Color(0xFF3A3A5A),
    unfocusedBorderColor = Color(0xFF1E1E2C),
    focusedLabelColor = Color(0xFF666688),
    unfocusedLabelColor = Color(0xFF444455),
    cursorColor = Color(0xFF4DABF7),
    focusedTextColor = Color.White,
    unfocusedTextColor = Color(0xFFCCCCDD)
)
