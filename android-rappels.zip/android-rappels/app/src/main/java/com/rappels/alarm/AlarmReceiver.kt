package com.rappels.alarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.rappels.R
import com.rappels.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val id            = intent.getIntExtra("id", -1)
        val title         = intent.getStringExtra("title") ?: "Rappel"
        val message       = intent.getStringExtra("message") ?: ""
        val type          = intent.getStringExtra("reminderType") ?: "beep"
        val recurrence    = intent.getStringExtra("recurrence") ?: "none"
        val every         = intent.getIntExtra("recurrenceEvery", 1)
        val triggerAt     = intent.getLongExtra("triggerAt", 0L)

        notify(context, id, title, message, type)
        if (type == "vibrate" || type == "all") vibrate(context)

        // Reschedule recurring alarm
        if (recurrence != "none" && id != -1) {
            val nextFire = nextOccurrence(triggerAt, recurrence, every)
            CoroutineScope(Dispatchers.IO).launch {
                val dao = AppDatabase.get(context).taskDao()
                dao.getById(id)?.let { task ->
                    if (!task.done) {
                        val updated = task.copy(triggerAt = nextFire)
                        dao.update(updated)
                        AlarmScheduler.schedule(context, updated)
                    }
                }
            }
        }
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun notify(context: Context, taskId: Int, title: String, message: String, type: String) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = when (type) {
            "alarm", "all"  -> ensureAlarmChannel(nm)
            "vibrate"       -> ensureVibrateChannel(nm)
            "notif"         -> ensureNotifChannel(nm)
            else            -> ensureBeepChannel(nm)
        }
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("⏰ $title")
            .setContentText(message.ifEmpty { "Rappel de tâche" })
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .build()
        nm.notify(taskId, notification)
    }

    private fun ensureBeepChannel(nm: NotificationManager): String {
        if (nm.getNotificationChannel("ch_beep") == null) {
            NotificationChannel("ch_beep", "Bip", NotificationManager.IMPORTANCE_HIGH).apply {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                setSound(uri, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build())
            }.also { nm.createNotificationChannel(it) }
        }
        return "ch_beep"
    }

    private fun ensureAlarmChannel(nm: NotificationManager): String {
        if (nm.getNotificationChannel("ch_alarm") == null) {
            NotificationChannel("ch_alarm", "Alarme", NotificationManager.IMPORTANCE_HIGH).apply {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                setSound(uri, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
                vibrationPattern = longArrayOf(0, 400, 200, 400)
                enableVibration(true)
            }.also { nm.createNotificationChannel(it) }
        }
        return "ch_alarm"
    }

    private fun ensureNotifChannel(nm: NotificationManager): String {
        if (nm.getNotificationChannel("ch_notif") == null) {
            NotificationChannel("ch_notif", "Notification", NotificationManager.IMPORTANCE_HIGH).apply {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                setSound(uri, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build())
                enableVibration(false)
            }.also { nm.createNotificationChannel(it) }
        }
        return "ch_notif"
    }

    private fun ensureVibrateChannel(nm: NotificationManager): String {
        if (nm.getNotificationChannel("ch_vibrate") == null) {
            NotificationChannel("ch_vibrate", "Vibreur", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
                vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 1000)
                enableVibration(true)
            }.also { nm.createNotificationChannel(it) }
        }
        return "ch_vibrate"
    }

    // ── Vibration ─────────────────────────────────────────────────────────────

    private fun vibrate(context: Context) {
        val pattern = longArrayOf(0, 300, 150, 300, 150, 600)
        val effect = VibrationEffect.createWaveform(pattern, -1)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager)
                .defaultVibrator.vibrate(effect)
        } else {
            @Suppress("DEPRECATION")
            (context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(effect)
        }
    }

    // ── Recurrence ────────────────────────────────────────────────────────────

    private fun nextOccurrence(current: Long, recurrence: String, every: Int): Long {
        val cal = Calendar.getInstance().apply { timeInMillis = current }
        when (recurrence) {
            "minutes" -> cal.add(Calendar.MINUTE, every)
            "hours"   -> cal.add(Calendar.HOUR_OF_DAY, every)
            "days"    -> cal.add(Calendar.DAY_OF_YEAR, every)
            "weeks"   -> cal.add(Calendar.WEEK_OF_YEAR, every)
            "months"  -> cal.add(Calendar.MONTH, every)
            "years"   -> cal.add(Calendar.YEAR, every)
        }
        return cal.timeInMillis
    }
}
