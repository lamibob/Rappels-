package com.rappels.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.rappels.data.Task

object AlarmScheduler {

    fun schedule(context: Context, task: Task) {
        if (task.triggerAt <= 0 || task.done) return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) return

        try {
            am.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                task.triggerAt,
                buildPendingIntent(context, task)
            )
        } catch (_: SecurityException) {}
    }

    fun cancel(context: Context, taskId: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(
            PendingIntent.getBroadcast(
                context, taskId,
                Intent(context, AlarmReceiver::class.java).apply {
                    action = "com.rappels.ALARM_FIRE"
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
    }

    private fun buildPendingIntent(context: Context, task: Task): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.rappels.ALARM_FIRE"
            putExtra("id", task.id)
            putExtra("title", task.title)
            putExtra("message", task.message)
            putExtra("reminderType", task.reminderType)
            putExtra("recurrence", task.recurrence)
            putExtra("recurrenceEvery", task.recurrenceEvery)
            putExtra("triggerAt", task.triggerAt)
        }
        return PendingIntent.getBroadcast(
            context, task.id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
