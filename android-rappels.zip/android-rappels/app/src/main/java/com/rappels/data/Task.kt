package com.rappels.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val message: String = "",
    val triggerAt: Long = 0L,         // Epoch ms of next/first alarm
    val recurrence: String = "none",  // none|minutes|hours|days|weeks|months|years
    val recurrenceEvery: Int = 1,
    val reminderType: String = "beep",// beep|alarm|notif|vibrate|all
    val done: Boolean = false,
    val colorIndex: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
